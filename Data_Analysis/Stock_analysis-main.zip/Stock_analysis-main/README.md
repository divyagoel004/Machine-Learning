Project on stock analysis
